import mesop as me


@me.page(path="/ia")
def app():
  me.text("Hello Worl asdsada")