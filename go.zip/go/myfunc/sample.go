package myfunc

func Sum(number1 int, number2 int) int {
	result:=number1+number2
    return result
}