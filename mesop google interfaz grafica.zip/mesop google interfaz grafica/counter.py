import mesop as me

@me.stateclass
class State:
    clicks: int

def button_click(event: me.ClickEvent):
    state = me.state(State)
    state.clicks += 1

@me.page(path="/counter")
def main():
    state = me.state(State)
    with me.box(
        style=me.Style(
            flex_direction="column",
            display="flex",
            padding=me.Padding.all(16),
            align_items="center",
             margin=me.Margin.symmetric(vertical=24, horizontal=12),
            background="green"
        )
    ):
        me.text(f"Clicks: {state.clicks}")
        me.button("Increment", on_click=button_click ,color="warn")

