package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	//boolean true o false
	//var prueba bool  = true
	//fmt.Println(prueba)

	//Integer enteros (number
  // var minumero int = 10.2
   //fmt.Println(minumero)


   //float //decimal o int
  // var micarrroza float64 = 10.5
   //fmt.Println(micarrroza)


  //string text
 // var mitexto string= "5 el pin"
 // fmt.Println(mitexto)


//multiple values
//x ,y := 10, 14
//fmt.Println(x, y)

//var(
 //	x=10 //integer 
//	y=15.5 //float
	//z="hello" // string
//)
//fmt.Println(x, y, z)

//constant (can not be changed)
 //const mycostante = 5
 //fmt.Println(mycostante)

 //matrices array
//var myarray = [5]int{20,21,22,23,32}
//fmt.Println(myarray)



//slice (dynamic-sized)
//var myslice []int
///var other_slice=[]int{1,2,3,4,5}
//myslice=append(myslice, other_slice... )
//myslice = append(myslice, 6)
//fmt.Println(myslice)



//output:=hello()
//fmt.Println(output)
 
//a := 12
//b := 18
//result := myfunc.Sum(a,b)
//fmt.Println(result)

//for bloque
//for i:=0; i < 4; i++ {
//	fmt.Println(i)
	//}

//while 2 si bien golan has no while loop but we can create it using for loop
//i:=0; 
//for i<10 { 
// fmt.Println("good like")
 //i++
//}


//3 range loop 
//var myarray=[5]int{1,2,3,4,5}
//index:=10
//value:=5
//for index,value= range myarray{
 ////  fmt.Println("the index of array:",index)
 //  fmt.Println("the value of array:",value)

//logical statements if else if, else , switch
//1 if
//i:=5
//v:=5
//if i == v{
//	fmt.Println("i and v are aequals to each other")
//}

//2 else if
 //i:=5
 //v:=5
//if i == 6{
	 //	fmt.Println("i and v are aequals to each other")
  //  }else if v ==i{
	//	fmt.Println("previous one is false ,i and v are aequals to each other")
	//}


//3 else 
 ////i:=5
 // v:=5
 //if i == 6{
 //	fmt.Println("i and v are aequals to each other")
 // }else if v !=i{
//	 	fmt.Println("previous one is false ,i and v are aequals to each other")
 //}else {
	//fmt.Println("all conditions are fase")
 //}


//4 switch-case
//var myarray = [3]int{10, 20, 30}
//switch myarray[0] {
//case 10:
	//fmt.Println("variables is 10")
//case 20:
	//fmt.Println("variable is 20")
//case 30 :
//	fmt.Println("variable is 30")
//default : 
//fmt.Println("unknown variable none of them are true")

//rock paper scissors game
var choices=[]string{"rock", "paper", "scissors"}
rand.Seed(time.Now().UnixNano())
userScore := 0
computerScore := 0
fmt.Println("Welcome to Rock-Paper-Scissors Game")

for {
   userChoice := ""
   fmt.Println("Enter your choice: ")
   fmt.Scanln(&userChoice)

   isValidChoice := false	
   var choice string

   for _,choice = range choices {
	if userChoice==choice {
		isValidChoice = true
		break
	}
}
 if !isValidChoice {
  fmt.Println("invalide choice, please enter rock paper or scissors")
  continue
 
}
computerChoice := choices[rand.Intn(len(choices))] //the range star from 0 and finisch on 2 it will not fake 3.
//let's determine the winner
if userChoice == computerChoice {
  fmt.Println("It's a tie")
}else if userChoice == "rock" && computerChoice=="scissors" || userChoice == "paper" && computerChoice == "rock"|| userChoice == "scissors" &&  computerChoice == "paper"{
	fmt.Println("Computer Win")
	computerScore++
}  else{
 fmt.Println("User win!!!!!")
 userScore++
}                  
  fmt.Println("User Score is: ", userScore,"Computer is score is: ", computerScore)     
  
  var ask_user string
  fmt.Println("Do you wan to play again? (y/n)")
  fmt.Scanln(&ask_user)

  if ask_user == "y"{
	continue
  }else if  ask_user == "n"{
	fmt.Println("thanks for playing")
	break 
  }
}
}

